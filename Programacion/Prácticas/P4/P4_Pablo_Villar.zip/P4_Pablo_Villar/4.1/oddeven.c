nclude <stdio.h>
#include <stdlib.h>

int main(){
		printf("Ingresa un número entero: ");
			int num;
				scanf("%d", &num);
					if (num % 2 == 0){
								printf("El número es par\n");}
							else {printf("El número es impar\n");
									}
}

